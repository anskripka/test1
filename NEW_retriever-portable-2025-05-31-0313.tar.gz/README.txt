Retriever portable node pack

1. Розпакуй архів на новому сервері:
   tar -xzvf NEW_retriever-portable-2025-05-31-0313.tar.gz

2. Створи config.toml (можеш взяти шаблон з config.toml.example)

3. Запусти retriever:
   ./retriever --config config.toml
